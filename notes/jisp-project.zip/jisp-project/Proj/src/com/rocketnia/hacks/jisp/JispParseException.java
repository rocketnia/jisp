package com.rocketnia.hacks.jisp;


public class JispParseException extends Exception
{
    static final long serialVersionUID = 0;
}